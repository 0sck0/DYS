package com.example.user.reminder;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import android.app.Activity;
import android.app.AppComponentFactory;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;
import java.util.Random;

public class Reminder_input extends AppCompatActivity {
    private String total_data;
    private boolean isModify;
    //날짜 데이터를 화면에 표시하는 뷰, 버튼을 눌렀을때 DatePickerDialog를 호출하는 버튼
    private TextView eDateDisplay;
    private ImageButton ePickDate;
    //알림 스위치 뷰와 그 상태를 화면에 출력하는 뷰
    private TextView ring_switch_on_text;
    private Switch ring_switch;
    //현재 저장되어 있는 날짜 데이터 변수들이다..
    private int ehour;
    private int eminute;
    private int eYear;
    private int eMonth;
    private int eDay;
    //제목, 내용의 뷰
    private EditText memo_reminder;
    private EditText title_reminder;
    //현재 액티비티를 취소하거나 저장하는 버튼
    private Button cancel_reminder;
    private Button save_reminder;

    private String recieve_title;
    private int switch1 = 0;
    static final int TIME_DIALOG_ID = 1;
    static final int DATE_DIALOG_ID = 0;
    private String path_reminder;
    private String filename;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder_input);

        Intent intent  = getIntent();
        path_reminder = getFilesDir().toString() + "/" + "Reminder";
        //새로운 일정을 생성하는건지, 기존 일정을 수정하는건지를 판단하는 코드
        if((isModify = intent.getBooleanExtra("isModify",false))) {
            recieve_title = intent.getStringExtra("title");
            filename = intent.getStringExtra("file name");
            //수정하는 거라면, 파일 파싱하여 데이터들에게 나눠줌.
            find_file();

        }
        else
        {
            //처음 날짜 정할때 오늘 날짜로 초기화하는 함수
            set_date();
        }
        title_reminder = (EditText)findViewById(R.id.title_reminder);
        //텍스트로 선택한 일정 보여주는 변수
        eDateDisplay = (TextView)findViewById(R.id.date_reminder);

        //날짜 선택하는 버튼
        ePickDate = (ImageButton)findViewById(R.id.ring_reminder);

        memo_reminder = (EditText)findViewById(R.id.memo_reminder);

        //현재 액티비티를 취소하거나 저장하는 버튼 //온클릭 리스너 만들어주고, 거기에는 인텐트 처리와 파일처리 코드를 넣을 예정.
        cancel_reminder = (Button)findViewById(R.id.cancel_reminder);
        save_reminder = (Button)findViewById(R.id.save_reminder);
        //날짜 변경 버튼 이벤트 리스너
        ePickDate.setOnClickListener((new View.OnClickListener(){
            public void onClick(View v)
            {
                switch1 = 1;
                showDialog(DATE_DIALOG_ID);
            }
        }));

        //취소 버튼과 저장 버튼 이벤트 리스너 설정
        cancel_reminder = (Button)findViewById(R.id.cancel_reminder);
        cancel_reminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });
        save_reminder = (Button)findViewById(R.id.save_reminder);
        save_reminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isModify) { //수정하는경우
                    if (recieve_title.equals(title_reminder)) {     //수정전 후 제목이 같을 경우는 파일 안의 데이터만 업데이트 해주고 끝.;
                          //파일 덮어쓰기
                        try {
                            BufferedWriter bw = new BufferedWriter((new FileWriter(path_reminder + "/" + filename, false)));
                            if (!make_data())    //데이터 입력이 제대로 됬는지 확인한다.
                            {
                                bw.write(total_data);
                                bw.close();
                                Intent reminderintent = new Intent();
                                setResult(10, reminderintent);
                                finish();
                            } else {
                                Toast.makeText(getApplicationContext(), "입력을 제대로 해주십시오.", Toast.LENGTH_SHORT).show();
                                return;
                            }
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    else {  //수정으로 인하여 제목이 바뀌는 경우에는 전의 제목과 현재 제목을 인텐트로 다시 보낸다.

                        String cur_title = title_reminder.getText().toString();

                        try {
                            BufferedWriter bw = new BufferedWriter((new FileWriter(path_reminder + "/" + filename, false)));
                            if (!make_data())    //데이터 입력이 제대로 됬는지 확인한다.
                            {
                                bw.write(total_data);
                                bw.close();
                                Intent reminderintent = new Intent();
                                reminderintent.putExtra("pre_title", recieve_title);
                                reminderintent.putExtra("cur_title", title_reminder.getText().toString());
                                reminderintent.putExtra("file name", filename);
                                setResult(20, reminderintent);
                                finish();
                            } else {
                                Toast.makeText(getApplicationContext(), "입력을 제대로 해주십시오.", Toast.LENGTH_SHORT).show();
                                return;
                            }
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                }
                else {  //수정이 아닌, 새로운 일정을 추가하는 경우는 파일을 생성하고 데이터를 쓴다.
                    String title = title_reminder.getText().toString();

                    Random random = new Random();
                    int rand = random.nextInt(100);
                    File file = new File(getFilesDir().toString() + "/" + "Reminder" + Integer.toString(rand));
                    while(file.exists())
                    {
                        rand = random.nextInt(100);
                        file = new File(getFilesDir().toString() + "/" + "Reminder" + Integer.toString(rand));
                    }
                    try {
                        BufferedWriter bw = new BufferedWriter((new FileWriter(path_reminder + "/" + Integer.toString(rand), false)));
                        if (!make_data())    //데이터 입력이 제대로 됬는지 확인한다.
                        {
                            bw.write(total_data);
                            bw.close();
                            Intent reminderintent = new Intent();
                            reminderintent.putExtra("title", title);
                            reminderintent.putExtra("file name", Integer.toString(rand));
                            setResult(100, reminderintent);
                            finish();
                        } else {
                            Toast.makeText(getApplicationContext(), "입력을 제대로 해주십시오.", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                }
            }
        });
    }
    private boolean make_data() {
        boolean sw = false;
        if (title_reminder.getText().toString().isEmpty()) {
            Toast.makeText(getApplicationContext(), "제목를 입력해주십시오.", Toast.LENGTH_LONG).show();
            sw = true;
        }
        if (memo_reminder.getText().toString().isEmpty()) {
            Toast.makeText(getApplicationContext(), "메모를 입력해주십시오.", Toast.LENGTH_LONG).show();
            sw = true;
        }
        if (eDateDisplay.getText().toString().isEmpty()) {
            Toast.makeText(getApplicationContext(), "종료 날짜를 입력해주십시오.", Toast.LENGTH_LONG).show();
            sw = true;
        }
        if (sw == true)
            return sw;
        else
        {
            total_data = title_reminder.getText().toString() + "\n"
                    + eDateDisplay.getText().toString() + "\n"
                    + memo_reminder.getText().toString();
            return false;
        }
    }
    //인텐트에서 받은 제목을 가지고 파일을 찾아서 파싱을 통해 초기화.
    private void find_file()
    {
        //미완성
    }
    //처음 날짜 정할때 오늘 날짜로 초기화하는 코드.
    private void set_date()
    {

        Calendar c = Calendar.getInstance();

        eYear = c.get(Calendar.YEAR);
        eMonth = c.get(Calendar.MONTH);
        eDay = c.get(Calendar.DAY_OF_MONTH);
        ehour = c.get(Calendar.HOUR_OF_DAY);
        eminute = c.get(Calendar.MINUTE);
    }

    //위의 날짜들의 데이터를 텍스트뷰에 출력
    private void updateDate()
    {
            eDateDisplay.setText(
                    new StringBuilder()
                            // Month is 0 based so add 1
                            .append(eYear).append(" ")
                            .append(eMonth + 1).append("/")
                            .append(eDay).append("/")
                            .append(pad(ehour)).append(":")
                            .append(pad(eminute)));
            showDialog(TIME_DIALOG_ID);

    }


    //일의 자리 숫자를 01 02 03 이런식으로 문자열로 변환하여 주는 함수
    private static String pad(int c)
    {
        if (c >= 10)
            return String.valueOf(c);
        else
            return "0" + String.valueOf(c);
    }

    //날짜를 선택했을 때 그에 따른

    DatePickerDialog.OnDateSetListener mDateSetListener =
            new DatePickerDialog.OnDateSetListener() {

                public void onDateSet(DatePicker view, int year,
                                      int monthOfYear, int dayOfMonth) {

                        eYear = year;
                        eMonth = monthOfYear;
                        eDay = dayOfMonth;
                        updateDate();
                }
            };


    // 시간 선택
    TimePickerDialog.OnTimeSetListener mTimeSetListener =
            new TimePickerDialog.OnTimeSetListener() {
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                        ehour = hourOfDay;
                        eminute = minute;
                        updateDate();
                }
            };

    @Override
    protected Dialog onCreateDialog(int id) {
        Log.v(Integer.toString(id), " : 1");

        switch (id) {
            case DATE_DIALOG_ID: {
                    return new DatePickerDialog(this,
                            mDateSetListener,
                            eYear, eMonth, eDay);
            }
            case TIME_DIALOG_ID: {
                    return new TimePickerDialog(this,
                            mTimeSetListener, ehour, eminute, false);
            }
        }
        return null;
    }
}