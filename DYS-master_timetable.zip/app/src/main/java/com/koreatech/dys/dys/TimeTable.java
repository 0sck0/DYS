package com.koreatech.dys.dys;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class TimeTable extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timetable);

        // 날짜 표시
        Calendar cal = Calendar.getInstance();
        weekPrintToTimeTable(cal);
    }

    // Actionbar_Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_timetable, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.menu_add:
                Intent intent = new Intent(this, TimeTable_Selected.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // 날짜 표기하기
    public void weekPrintToTimeTable(Calendar mCalendar) {
        Date date = new Date();
        Date[] thisWeek = new Date[5];
        String[] thisWeekString = new String[5];
        mCalendar.setTime(date);

        // 1 = 일요일, 2 = 월요일
        int day_of_week = mCalendar.get(Calendar.DAY_OF_WEEK);

        int monday_offset;
        if (day_of_week == 1) {
            monday_offset = -6;
        } else
            monday_offset = (2 - day_of_week); // 음수로 설정

        // 월요일부터 시작
        mCalendar.set(Calendar.DAY_OF_YEAR, monday_offset);

        mCalendar.add(Calendar.MONTH, -1);
        // 화, 수, 목, 금 출력하기
        for(int i=0; i<5; i++) {
            mCalendar.add(Calendar.DAY_OF_YEAR, 1);
            thisWeek[i] = mCalendar.getTime();
        }

        // 출력할 포맷 만들기
        String strDateFormat = "MM/dd";
        SimpleDateFormat sdf = new SimpleDateFormat(strDateFormat);

        for(int i=0; i<5; i++) {
            thisWeekString[i] = sdf.format(thisWeek[i]);
        }

        // TextView에 넣기
        TextView[] days = new TextView[5];
        days[0] = (TextView)findViewById(R.id.mondayDate);
        days[1] = (TextView)findViewById(R.id.tusedayDate);
        days[2] = (TextView)findViewById(R.id.wednesdayDate);
        days[3] = (TextView)findViewById(R.id.thursdayDate);
        days[4] = (TextView)findViewById(R.id.fridayDate);

        for(int i=0; i<5; i++) {
            days[i].setText(thisWeekString[i]);
        }

    }
}
