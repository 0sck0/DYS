package com.koreatech.dys.dys;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

public class TimeTable_Selected extends AppCompatActivity {

    // 시간 설정 관련 변수
    private int mHour, mMinute;
    private String ampm;
    View lastView;
    TextView startTime;
    TextView endTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timetable_selected);

        // 텍스트 뷰 연결
        startTime = (TextView) findViewById(R.id.startTime);
        endTime = (TextView) findViewById(R.id.endTime);

        // Calendar instance 선언
        Calendar cal = new GregorianCalendar();
        mHour = cal.get(Calendar.HOUR_OF_DAY);
        mMinute = cal.get(Calendar.MINUTE);

    }

    // Actionbar_Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_timetable_selected, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.menu_back:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void setTime(View v) {
        lastView = v;

        TimePickerDialog tp = new TimePickerDialog(this,
                TimePickerDialog.THEME_HOLO_LIGHT, mTimeSetListner, mHour, mMinute, false);

        tp.show();
    }

    TimePickerDialog.OnTimeSetListener mTimeSetListner = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            mHour = hourOfDay;
            mMinute = minute;

            // 최대 최소치 제한
            if(mHour < 8) {
                mHour = 8; mMinute = 0;
                Toast.makeText(getApplicationContext(), "최소 8시까지 설정이 가능합니다.", Toast.LENGTH_SHORT).show();
            } else if(mHour >= 18 && mMinute != 0) {
                mHour = 18; mMinute = 0;
                Toast.makeText(getApplicationContext(), "최대 18시까지 설정이 가능합니다.", Toast.LENGTH_SHORT).show();
            } else {

            }

            // 오전 오후 구분
            if(mHour > 11) {
                ampm = "오후";
            } else {
                ampm = "오전";
            }

            // 오후일 시 시간 12시간 감소 (13시 → 오후 1시)
            if(mHour >= 13) {
                mHour -= 12;
            }

            switch (lastView.getId()) {
                case R.id.setStartTime:
                    startTime.setText(String.format("%s %d:%02d", ampm, mHour, mMinute));
                    break;
                case R.id.setEndTime:
                    endTime.setText(String.format("%s %d:%02d", ampm, mHour, mMinute));
                    break;
                default:
                    break;
            }
        }
    };

    public void checkTheTime() {

    }


}