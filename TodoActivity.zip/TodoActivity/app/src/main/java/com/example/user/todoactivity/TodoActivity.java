package com.example.user.todoactivity;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.String;

import android.content.Intent;

import android.support.v7.view.ActionMode;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public class TodoActivity extends AppCompatActivity
        implements AdapterView.OnItemLongClickListener, ActionMode.Callback {
    //리스트 뷰를 이용하기 위해 전역변수로 선언하였다.
    private ListView m_ListView;
    //리스트 뷰와 item들의 연결점인 ArrayAdapter를 선언하였다.
    private ArrayAdapter<String> m_Adapter;
    //컨텍스트 액션모드를 이용하기 위한 변수이다.
    private ActionMode mActionMode;
    //리스트 뷰에서 롱클릭을 하였을때, 롱클릭된 뷰의 이름을 저장하는 변수이다
    private String renm;
    //Todo의 경로
    private String path_todo;
    private List<String> fileNum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo);
        fileNum = new ArrayList<String>();
        /* /data */
        path_todo = getFilesDir().toString() + "/" + "Todo";
        File dir = new File(path_todo);
        if(!dir.isDirectory())
        {
            dir.mkdirs();
        }

        //xml파일에는 id가 list인 리스트뷰가 코딩되어 있으므로 그 뷰를 변수에 이어준다.
        m_ListView = (ListView) findViewById(R.id.list_todo);
        //처음 앱이 실행될때, 정해진 경로의 폴더(나는 내부저장소로 정햇다)에 있는 파일들을 File 배열
        //에 listFiles함수를 이용하여 넣는다.
        try {
            make_list();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    //list 뷰에 list를 추가
    private void make_list() throws IOException {
        File[] listFile = new File(path_todo).listFiles();
        //문자열 리스트를 선언하여, 가져온 모든 파일의 이름을 리스트에 저장한다.
        List<String> list = new ArrayList<String>();
        Log.v("is", "ok?");
        for (File file : listFile)
        {
            fileNum.add(file.getName());
            FileReader filereader = new FileReader(file);
            BufferedReader bufReader = new BufferedReader(filereader);
            list.add(bufReader.readLine());
        }
        //그리고 파일의 이름을 어답터에 연결한다. 이때 설정하는 리스트의 종류는 simple_list_item_1이다.
        m_Adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
        //리스트뷰는 xml파일에 있는 list와 연결한 후, Adapter에 연결한다. 그럼 리스트뷰에는 Adapter가
        //연결하였던 list의 데이터들이 item으로 보이게 된다.
        m_ListView = (ListView) findViewById(R.id.list_todo);
        m_ListView.setAdapter(m_Adapter);
        //이때 item들을 눌러서 웹사이트를 연결하기 위한 이벤트리스너를 설정한다.
        m_ListView.setOnItemClickListener(onClickListItem);
        //item들이 길게 눌렸을 때 반응하는 이벤트리스너 또한 설정하는데, 이때는 implements로 Adapter
        // View.OnItemLongClickListener를 해줬기 때문에 이벤트리스너의 인자에는 this가 들어간다.
        m_ListView.setOnItemLongClickListener(this);
    }
    //콘텍스트 액션 모드 구현
    //ActionMode.Callback implements 했기 때문에 클래스 안에 해당하는 함수를 만든다
    // 이 함수는 컨텍스트 액션 모드를 생성하는 함수이다.
    @Override
    public boolean onCreateActionMode(ActionMode mode, Menu menu) {
        MenuInflater inflater = mode.getMenuInflater();
        inflater.inflate(R.menu.menu_todo_context, menu);
        return true;
    }

    //이 함수는 준비하는? 함수인거 같은데 정확히 하는 일은 잘 모르겠다. 액션모드 객체를 초기화해주는?
    //그런 용도인 것 같다.
    @Override
    public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
        return false;
    }

    //롱클릭하여 액션모드가 보이게 되었을때, 사용자가 액션모드의 메뉴 아이템을 눌렀을때 이벤트함수이다.
    //여기서 액션모드가 보였을때, remove라는 item이 보이고 그것을 눌렀을때 롱클릭되었던 아이템뷰가
    //사라져야 한다. 따라서 어답터와 아이템뷰의 연결을 해제하고, 아이템뷰가 해당되는 파일을 삭제한다.(delete함수 사용)
    //그리고 삭제여부를 토스트 메세지로 사용자에게 알린다. 그리고 컨텍스트 액션모드를 종료한다.
    @Override
    public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
        switch (item.getItemId()) {
            case R.id.remove_todo:
                m_Adapter.remove(renm);
                File df = new File(path_todo + "/" + renm);

                if (df.delete())
                    Toast.makeText(getApplicationContext(), "성공적으로 삭제되었습니다.", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(getApplicationContext(), "예기치 못한 오류로 삭제를 하지 못하였습니다.", Toast.LENGTH_SHORT).show();
                mode.finish();
                return true;
            default:
                return false;
        }
    }

    // 사용자가 컨텍스트 액션 모드를 빠져나갈 때 호출하는 함수이다.
    @Override
    public void onDestroyActionMode(ActionMode mode) {
        mActionMode = null;
    }

    //사용자가 item을 길게 눌렀을때 호출되는 함수이다.
    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        if (mActionMode != null) {
            return false;
        }
        renm = m_Adapter.getItem(position);
        // 컨텍스트 액션 모드 시작
        mActionMode = startSupportActionMode(this);
        view.setSelected(true);
        return true;
    }
    //콘텍스트 액션 모드 구현 끝


    //기본 화면에서 item들을 짧게 눌렀을 때 호출되는 함수이다. url을 이용하여 웹사이트를 연결한다.
    private AdapterView.OnItemClickListener onClickListItem = new AdapterView.OnItemClickListener() {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            // 클릭 이벤트 발생시 수정 작업으로써, intent호출하여 TodoInputActivity실행
            String title = m_Adapter.getItem(position);
            Intent todointent = new Intent(getApplicationContext(), TodoInputActivity.class);
            todointent.putExtra("isModify", true);
            todointent.putExtra("title", title);
            todointent.putExtra("file name", fileNum.get(position));
            startActivityForResult(todointent, 100);
        }
    };

    //기본 화면에서의 옵션 메뉴를 생성하는 함수이다.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_todo, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //기본 화면에서의 옵션 메뉴를 눌렀을때 즉, add를 눌렀을 때 addActivity를 호출하는 함수이다.
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add_todo:
                //서브 액티비티 호출, 인텐트로 데이터 소통,
                Intent todointent = new Intent(getApplicationContext(), TodoInputActivity.class);
                todointent.putExtra("isModify", false);
                startActivityForResult(todointent, 100);
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return false;
    }

    //addActivity로 부터 오는 데이터를 받는 함수이다.
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == 100) {
            String nm = data.getStringExtra("title");
            m_Adapter.add(nm);
            fileNum.add(data.getStringExtra("file name"));
            return;
        }
        else if(resultCode == 20)
        {
            m_Adapter.remove(data.getStringExtra("pre_title"));
            m_Adapter.add(data.getStringExtra("cur_title"));
            fileNum.remove(data.getStringExtra("file name"));
            fileNum.add(data.getStringExtra("file name"));
            return;
        }
        else if(resultCode == 10)
        {
            return;
        }
        else
        {
            Toast.makeText(this, "취소 되었습니다.", Toast.LENGTH_SHORT).show();
            return;
        }

    }
}
