package com.example.user.dys;

import android.app.Dialog;
import android.app.TimePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;


import com.applandeo.materialcalendarview.CalendarView;
import com.applandeo.materialcalendarview.EventDay;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    public static final String RESULT = "result";
    public static final String EVENT = "event";
    private static final int ADD_NOTE = 44;
    private List<EventDay> mEventDays = new ArrayList<>();
    //스터디 인풋창
    LinearLayout study_input;
    //제목, 내용의 뷰
    private EditText title_study;
    private EditText content_study;
    //현재 액티비티를 취소하거나 저장하는 버튼
    private Button cancel_study;
    private Button save_study;
    //날짜 데이터를 화면에 표시하는 뷰, 버튼을 눌렀을때 DatePickerDialog를 호출하는 버튼
    private TextView sTimeDisplay, eTimeDisplay;
    private Button sPickTime, ePickTime;
    //알림 스위치 뷰와 그 상태를 화면에 출력하는 뷰
    private TextView ring_switch_on_text;
    private Switch ring_switch;
    //현재 저장되어 있는 날짜 데이터 변수들이다..
    private int shour, ehour;
    private int sminute, eminute;
    private int cYear;
    private int cMonth;
    private int cDay;
    private int switch1 = 0;
    static final int TIME_DIALOG_ID = 1;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 달력 출력 코드
        Calendar calendar = Calendar.getInstance();
        //calendar.add(Calendar.DAY_OF_MONTH, 2);
        List<EventDay> events = new ArrayList<>();
        CalendarView calendarView = findViewById(R.id.calendarView);
        //처음 날짜를 오늘로 초기화하는 함수
        set_date();
        //사용자가 날짜를 클릭하였을때 스터디 입력창을 띄운다.
        calendarView.setOnDayClickListener((EventDay eventDay) ->
        {
            Calendar clickedDayCalendar = eventDay.getCalendar();
            //사용자가 클릭한 날짜의 값을 인트로 받아 올수 있음!
            Log.v(Integer.toString(eventDay.getCalendar().get(Calendar.DAY_OF_MONTH)), " : date");
            //events.add(new EventDay(clickedDayCalendar, R.drawable.ic_launcher_background));
            //calendarView.setEvents(events);
            study_input.setVisibility(View.VISIBLE);
            //파일에 그 날짜에 지정한 스터디 정보가 있다면 입력창 데이터 변수에 가지고 와서 화면에 출력한다.
            //cancel버튼을 눌렀을때는 다시 입력창이 사라지게 한다. 그리고 입력창의 데이터들을 초기화시킨다.
            //만약 저장버튼을 눌렀다면, 입력창이 사라지게 하고, 입력창의 데이터들을 파일에 저장한다.
        });
        //입력창 선언******************************************************************************
        study_input = (LinearLayout) findViewById(R.id.study_input);
        sTimeDisplay = (TextView) findViewById(R.id.start_time_study);
        eTimeDisplay = (TextView) findViewById(R.id.end_time_study);
        title_study = (EditText) findViewById(R.id.title_study);
        content_study = (EditText) findViewById((R.id.content_study));

        //현재 액티비티를 취소하거나 저장하는 버튼 //온클릭 리스너 만들어주고, 거기에는 인텐트 처리와 파일처리 코드를 넣을 예정.
        cancel_study = (Button) findViewById(R.id.cancel_study);
        save_study = (Button) findViewById(R.id.save_study);

        //시간 선택하는 버튼
        sPickTime = (Button) findViewById(R.id.start_timepicker);
        sPickTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch1 = 0;
                showDialog(TIME_DIALOG_ID);
            }
        });
        ePickTime = (Button) findViewById(R.id.end_timepicker);
        ePickTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch1 = 1;
                showDialog(TIME_DIALOG_ID);
            }
        });

        //알림 스위치와 스위치 상태를 표시해주는 텍스트뷰
        ring_switch = (Switch) findViewById(R.id.switch_study);
        ring_switch_on_text = (TextView) findViewById(R.id.switch_condition_study);
        //스위치 버튼 이벤트 리스너
        ring_switch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_switch_checkState();
            }
        });
        ring_switch_checkState();
        //*****************************************************************************************


    }
    //스위치 상태를 텍스트에 출력해주는 함수 ( 알림 기능을 추가해주어야함.

    private void ring_switch_checkState() {
        if (ring_switch.isChecked())
            ring_switch_on_text.setText("On");
        else
            ring_switch_on_text.setText("Off");
    }
    //날짜를 오늘로 초기화해주는 함수
    private void set_date() {
        Calendar c = Calendar.getInstance();

        cYear = c.get(Calendar.YEAR);
        cMonth = c.get(Calendar.MONTH);
        cDay = c.get(Calendar.DAY_OF_MONTH);
        shour = c.get(Calendar.HOUR_OF_DAY);
        sminute = c.get(Calendar.MINUTE);
        ehour = c.get(Calendar.HOUR_OF_DAY);
        eminute = c.get(Calendar.MINUTE);
    }
    //위의 날짜들의 데이터를 텍스트뷰에 출력
    private void updateDate()
    {
        if(switch1 == 0)
        {
            sTimeDisplay.setText(
                    new StringBuilder()
                            .append(pad(shour)).append(":")
                            .append(pad(sminute)));
        }
        else
        {
            eTimeDisplay.setText(
                    new StringBuilder()
                            .append(pad(ehour)).append(":")
                            .append(pad(eminute)));
        }

    }
    // 시간 선택
    TimePickerDialog.OnTimeSetListener mTimeSetListener =
            new TimePickerDialog.OnTimeSetListener() {
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    if (switch1 == 0) {
                        shour = hourOfDay;
                        sminute = minute;
                    } else {
                        ehour = hourOfDay;
                        eminute = minute;
                    }

                    updateDate();
                }
            };
    //시간을 1분이면 01로 바꿔서 문자열로 바꿔주는 함수
    private static String pad(int c)
    {
        if (c >= 10)
            return String.valueOf(c);
        else
            return "0" + String.valueOf(c);
    }
    @Override
    protected Dialog onCreateDialog(int id) {
        if (switch1 == 0)
            return new TimePickerDialog(this,
                    mTimeSetListener, shour, sminute, false);
        else
            return new TimePickerDialog(this,
                    mTimeSetListener, ehour, eminute, false);
    }
}