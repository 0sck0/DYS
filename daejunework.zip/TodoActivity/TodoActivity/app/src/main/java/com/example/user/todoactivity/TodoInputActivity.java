package com.example.user.todoactivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AppComponentFactory;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;
import java.util.Random;

public class TodoInputActivity extends AppCompatActivity {
    private String total_data;
    private boolean isModify;
    //날짜 데이터를 화면에 표시하는 뷰, 버튼을 눌렀을때 DatePickerDialog를 호출하는 버튼
    private TextView sDateDisplay, eDateDisplay;
    private Button sPickDate, ePickDate;
    //알림 스위치 뷰와 그 상태를 화면에 출력하는 뷰
    private TextView ring_switch_on_text;
    private Switch ring_switch;
    //현재 저장되어 있는 날짜 데이터 변수들이다..
    private int shour, ehour;
    private int sminute, eminute;
    private int sYear, eYear;
    private int sMonth, eMonth;
    private int sDay, eDay;
    private DBclass todoDB;
    private SQLiteDatabase db;
    private Cursor cursor;
    //제목, 내용의 뷰
    private EditText title_todo;
    private EditText content_todo;
    //현재 액티비티를 취소하거나 저장하는 버튼
    private Button cancel_todo;
    private Button save_todo;
    private boolean fin = true;
    private String recieve_title;
    private int switch1 = 0;
    static final int TIME_DIALOG_ID = 1;
    static final int DATE_DIALOG_ID = 0;
    private String path_todo;
    private String filename;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo_input);
        todoDB = new DBclass(this);
        try {
            db = todoDB.getWritableDatabase();
            db = todoDB.getReadableDatabase();
        } catch (SQLiteException ex) {
            db = todoDB.getReadableDatabase();
        }
        Intent intent  = getIntent();
        //텍스트로 선택한 일정 보여주는 변수
        sDateDisplay = (TextView)findViewById(R.id.start_date_todo);
        eDateDisplay = (TextView)findViewById(R.id.end_date_todo);

        //날짜 선택하는 버튼
        sPickDate = (Button)findViewById(R.id.start_datepicker);
        ePickDate = (Button)findViewById(R.id.end_datepicker);
        //알림 스위치와 스위치 상태를 표시해주는 텍스트뷰
        ring_switch = (Switch)findViewById(R.id.switch_todo);
        ring_switch_on_text = (TextView)findViewById(R.id.switch_condition_todo);
        title_todo = (EditText)findViewById(R.id.title_todo);
        content_todo = (EditText)findViewById((R.id.content_todo));
        //현재 액티비티를 취소하거나 저장하는 버튼 //온클릭 리스너 만들어주고, 거기에는 인텐트 처리와 파일처리 코드를 넣을 예정.
        cancel_todo = (Button)findViewById(R.id.cancel_todo);
        save_todo = (Button)findViewById(R.id.save_todo);
        //날짜 변경 버튼 이벤트 리스너
        sPickDate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                switch1 = 0;
                showDialog(DATE_DIALOG_ID);
            }
        });
        ePickDate.setOnClickListener((new View.OnClickListener(){
            public void onClick(View v)
            {
                switch1 = 1;
                showDialog(DATE_DIALOG_ID);
            }
        }));
        //스위치 버튼 이벤트 리스너
        ring_switch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_switch_checkState();
            }
        });
        //취소 버튼과 저장 버튼 이벤트 리스너 설정
        cancel_todo = (Button)findViewById(R.id.cancel_todo);
        cancel_todo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });
        save_todo = (Button)findViewById(R.id.save_todo);
        save_todo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!check_data()) {
                    String cur_title = title_todo.getText().toString();
                    String content = content_todo.getText().toString();
                    String start_date = sDateDisplay.getText().toString();
                    String end_date = eDateDisplay.getText().toString();
                    String ring_switch = ring_switch_on_text.getText().toString();
                    if (isModify) {
                        //수정하는경우

                        if(title_todo.getText().toString().equals(recieve_title))
                            db.execSQL("UPDATE todo " +
                                    "SET title = '" + cur_title +
                                    "', start_date = '" + start_date +
                                    "', end_date = '" + end_date +
                                    "', alarm = '" + ring_switch +
                                    "', content = '" + content +
                                    "' WHERE title = '" + recieve_title + "';");
                        else
                        {
                            db.execSQL("DELETE FROM todo " +
                                    "WHERE title = '" + recieve_title + "';");
                            db.execSQL("INSERT INTO todo " +
                                    "VALUES (null, '" + cur_title + "', '" + start_date + "', '"
                                    + end_date + "', '" + ring_switch + "', '" + content + "');");
                        }
                        finish();
                    } else {  //수정이 아닌, 새로운 일정을 추가하는 경우는 데이터베이스에 추가
                        cursor = db.rawQuery("SELECT * FROM todo " +
                                "WHERE title='" + cur_title + "';", null);
                        // 반환된 커서에 ResultSets의 행의 개수가 0개일 경우
                        if(cursor.getCount() == 0) {
                            db.execSQL("INSERT INTO todo " +
                                    "VALUES (null, '" + cur_title + "', '" + start_date + "', '"
                                    + end_date + "', '" + ring_switch + "', '" + content + "');");
                            finish();
                        }
                        else
                        {
                            //메세지 박스 출력 -> 확인 취소, 이때 확인 누르면 덮어쓰기, 취소하면 그대로 액티비티에 머무름.
                            AlertDialog.Builder alert_confirm = new AlertDialog.Builder(TodoInputActivity.this);
                            alert_confirm.setMessage("동일한 제목의 일정이 존재합니다. 덮어 쓰시겠습니까?").setCancelable(false).setPositiveButton("덮어쓰기",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            String cur_title = title_todo.getText().toString();
                                            String content = content_todo.getText().toString();
                                            String start_date = sDateDisplay.getText().toString();
                                            String end_date = eDateDisplay.getText().toString();
                                            String ring_switch = ring_switch_on_text.getText().toString();
                                            db.execSQL("UPDATE todo " +
                                                    "SET title = '" + cur_title +
                                                    "', start_date = '" + start_date +
                                                    "', end_date = '" + end_date +
                                                    "', alarm = '" + ring_switch +
                                                    "', content = '" + content +
                                                    "' WHERE title = '" + cur_title + "';");
                                            finish();
                                        }
                                    }).setNegativeButton("취소",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            fin = false;
                                            return;
                                        }
                                    });
                            AlertDialog alert = alert_confirm.create();
                            alert.show();
                        }
                        if(fin == false)
                            return;
                    }
                }
                else
                    Toast.makeText(getApplicationContext(), "입력을 제대로 해주십시오.", Toast.LENGTH_LONG).show();
            }
        });
        //새로운 일정을 생성하는건지, 기존 일정을 수정하는건지를 판단하는 코드
        if((isModify = intent.getBooleanExtra("isModify",false))) {
            recieve_title = intent.getStringExtra("title");
            cursor = db.rawQuery("SELECT * FROM todo " +
                    "WHERE title='" + recieve_title + "';", null);
            // 반환된 커서에 ResultSets의 행의 개수가 0개일 경우
            if(cursor.getCount() == 0) {
                Toast.makeText(getApplicationContext(), "해당 이름이 없습니다", Toast.LENGTH_SHORT).show();
                return;
            }
            cursor.moveToFirst();
            title_todo.setText(cursor.getString(1));
            sDateDisplay.setText(cursor.getString(2));
            eDateDisplay.setText(cursor.getString(3));
            content_todo.setText(cursor.getString(5));
            if(cursor.getString(4).equals("ON"))
                ring_switch.setChecked(true);
            else
                ring_switch.setChecked(false);
        }
        else
        {
            //처음 날짜 정할때 오늘 날짜로 초기화하는 함수
            set_date();
        }

    }
    private boolean check_data() {
            boolean sw = false;
            if (title_todo.getText().toString().isEmpty()) {
                Toast.makeText(getApplicationContext(), "제목를 입력해주십시오.", Toast.LENGTH_LONG).show();
                sw = true;
            }
            if (sDateDisplay.getText().toString().isEmpty()) {
                Toast.makeText(getApplicationContext(), "시작 날짜를 입력해주십시오.", Toast.LENGTH_LONG).show();
                sw = true;
            }
            if (eDateDisplay.getText().toString().isEmpty()) {
                Toast.makeText(getApplicationContext(), "종료 날짜를 입력해주십시오.", Toast.LENGTH_LONG).show();
                sw = true;
            }
            if (ring_switch_on_text.getText().toString().isEmpty()) {
                Toast.makeText(getApplicationContext(), "알림을 설정해주십시오.", Toast.LENGTH_LONG).show();
                sw = true;
            }
            if (content_todo.getText().toString().isEmpty()) {
                Toast.makeText(getApplicationContext(), "내용을 입력해주십시오.", Toast.LENGTH_LONG).show();
                sw = true;
            }
            return sw;
    }
    //처음 날짜 정할때 오늘 날짜로 초기화하는 코드.
    private void set_date()
    {

        Calendar c = Calendar.getInstance();

        sYear = c.get(Calendar.YEAR);
        sMonth = c.get(Calendar.MONTH);
        sDay = c.get(Calendar.DAY_OF_MONTH);
        shour = c.get(Calendar.HOUR_OF_DAY);
        sminute = c.get(Calendar.MINUTE);
        eYear = c.get(Calendar.YEAR);
        eMonth = c.get(Calendar.MONTH);
        eDay = c.get(Calendar.DAY_OF_MONTH);
        ehour = c.get(Calendar.HOUR_OF_DAY);
        eminute = c.get(Calendar.MINUTE);
    }
    //스위치 상태를 텍스트에 출력 + 알림해주는 기능 추가해야함

    private void ring_switch_checkState()
    {
        if(ring_switch.isChecked())
            ring_switch_on_text.setText("On");
        else
            ring_switch_on_text.setText("Off");
    }
    //위의 날짜들의 데이터를 텍스트뷰에 출력
    private void updateDate()
    {
        if(switch1 == 0)
        {
            sDateDisplay.setText(
                    new StringBuilder()
                            // Month is 0 based so add 1
                            .append(sYear).append(" ")
                            .append(sMonth + 1).append("/")
                            .append(sDay).append("/")
                            .append(pad(shour)).append(":")
                            .append(pad(sminute)));
            showDialog(TIME_DIALOG_ID);
        }
        else
        {
            eDateDisplay.setText(
                    new StringBuilder()
                            // Month is 0 based so add 1
                            .append(eYear).append(" ")
                            .append(eMonth + 1).append("/")
                            .append(eDay).append("/")
                            .append(pad(ehour)).append(":")
                            .append(pad(eminute)));
            showDialog(TIME_DIALOG_ID);
        }

    }


    //일의 자리 숫자를 01 02 03 이런식으로 문자열로 변환하여 주는 함수
    private static String pad(int c)
    {
        if (c >= 10)
            return String.valueOf(c);
        else
            return "0" + String.valueOf(c);
    }

    //날짜를 선택했을 때 그에 따른

    DatePickerDialog.OnDateSetListener mDateSetListener =
            new DatePickerDialog.OnDateSetListener() {

                public void onDateSet(DatePicker view, int year,
                                      int monthOfYear, int dayOfMonth) {
                    if(switch1 == 0)
                    {
                        sYear = year;
                        sMonth = monthOfYear;
                        sDay = dayOfMonth;
                    }
                    else
                    {
                        eYear = year;
                        eMonth = monthOfYear;
                        eDay = dayOfMonth;
                    }
                    updateDate();
                }
            };


    // 시간 선택
    TimePickerDialog.OnTimeSetListener mTimeSetListener =
            new TimePickerDialog.OnTimeSetListener() {
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    if(switch1 == 0) {
                        shour = hourOfDay;
                        sminute = minute;
                    }
                    else
                    {
                        ehour = hourOfDay;
                        eminute = minute;
                    }

                    updateDate();
                }
            };

    @Override
    protected Dialog onCreateDialog(int id) {
        Log.v(Integer.toString(id), " : 1");

        switch (id) {
            case DATE_DIALOG_ID: {
                if (switch1 == 0)
                    return new DatePickerDialog(this,
                            mDateSetListener,
                            sYear, sMonth, sDay);
                else
                    return new DatePickerDialog(this,
                            mDateSetListener,
                            eYear, eMonth, eDay);
            }
            case TIME_DIALOG_ID: {
                if (switch1 == 0)
                    return new TimePickerDialog(this,
                            mTimeSetListener, shour, sminute, false);
                else
                    return new TimePickerDialog(this,
                            mTimeSetListener, ehour, eminute, false);
            }
        }
        return null;
    }
}

